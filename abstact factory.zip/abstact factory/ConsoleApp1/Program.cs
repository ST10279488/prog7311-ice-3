﻿using GalaxyGadgetStore.Factories;
using GalaxyGadgetStore.Services;
using System;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to Galaxy Gadget Store!");
        Console.WriteLine("Please choose a brand: 1. Samsung 2. Apple");
        int choice = int.Parse(Console.ReadLine());

        IGadgetFactory factory = null;

        switch (choice)
        {
            case 1:
                factory = new SamsungFactory();
                break;
            case 2:
                factory = new AppleFactory();
                break;
            default:
                Console.WriteLine("Invalid choice.");
                return;
        }

        GalaxyGadgetStore store = new GalaxyGadgetStore(factory);
        store.DisplayGadgets();
    }
}
